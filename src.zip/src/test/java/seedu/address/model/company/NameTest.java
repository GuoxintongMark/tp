package seedu.address.model.company;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static seedu.address.testutil.Assert.assertThrows;

import org.junit.jupiter.api.Test;

public class NameTest {

    @Test
    public void constructor_null_throwsNullPointerException() {
        assertThrows(NullPointerException.class, () -> new Name(null));
    }

    @Test
    public void constructor_invalidName_throwsIllegalArgumentException() {
        String invalidName = "";
        assertThrows(IllegalArgumentException.class, () -> new Name(invalidName));
    }

    @Test
    public void isValidName() {
        // null name
        assertThrows(NullPointerException.class, () -> Name.isValidName(null));

        // invalid name
        assertFalse(Name.isValidName("")); // empty string
        assertFalse(Name.isValidName(" ")); // spaces only
        assertFalse(Name.isValidName("^")); // only non-alphanumeric characters
        assertFalse(Name.isValidName("Logistics@Hub")); // contains non-alphanumeric characters

        // valid name
        assertTrue(Name.isValidName("Acme Logistics")); // alphabets and spaces
        assertTrue(Name.isValidName("12345")); // numbers only
        assertTrue(Name.isValidName("Warehouse 7")); // alphanumeric characters
        assertTrue(Name.isValidName("Capital Freight")); // with capital letters
        assertTrue(Name.isValidName("Global Distribution Services Pte Ltd 2")); // long business names
    }

    @Test
    public void equals() {
        Name name = new Name("Acme Logistics");

        // same values -> returns true
        assertTrue(name.equals(new Name("Acme Logistics")));

        // same object -> returns true
        assertTrue(name.equals(name));

        // null -> returns false
        assertFalse(name.equals(null));

        // different types -> returns false
        assertFalse(name.equals(5.0f));

        // different values -> returns false
        assertFalse(name.equals(new Name("Zenith Freight")));
    }
}
